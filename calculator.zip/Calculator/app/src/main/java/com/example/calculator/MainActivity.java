package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static com.example.calculator.R.id.add;
import static com.example.calculator.R.id.summation;

public class MainActivity extends AppCompatActivity {

    private Button div,mul,sub,sum,zero,one,two,three,four,five,six,seven,eight,nine,point,backspace,equal;
    private EditText resultview;
    boolean division,multiply,subtract,summation;
    float res1,res2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        zero= (Button)findViewById(R.id.zero);
        one= (Button)findViewById(R.id.one);
        two= (Button)findViewById(R.id.two);
        three= (Button)findViewById(R.id.three);
        four= (Button)findViewById(R.id.four);
        five= (Button)findViewById(R.id.five);
        six= (Button)findViewById(R.id.six);
        seven= (Button)findViewById(R.id.seven);
        eight= (Button)findViewById(R.id.eight);
        nine= (Button)findViewById(R.id.nine);
        point= (Button)findViewById(R.id.point);
        backspace= (Button)findViewById(R.id.backspace);
        equal= (Button)findViewById(R.id.enter);
        equal= (Button)findViewById(R.id.enter);
        sum= (Button)findViewById(R.id.summation);
        sub= (Button)findViewById(R.id.subtraction);
        mul= (Button)findViewById(R.id.multiplication);
        div= (Button)findViewById(R.id.division);
        resultview =(EditText) findViewById(R.id.resultview);
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"1");
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"2");
            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"3");
            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"4");
            }
        });
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"5");
            }
        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"6");
            }
        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"7");
            }
        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"8");
            }
        });
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"9");
            }
        });
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+"0");
            }
        });
        point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText(resultview.getText()+".");
            }
        });
        sum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(resultview==null){
                    resultview.setText("");
                }
                else {
                    res1=Float.parseFloat(resultview.getText()+"");
                    summation = true;
                    resultview.setText(null);
                }
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(resultview==null){
                    resultview.setText("");
                }
                else {
                    res1=Float.parseFloat(resultview.getText()+"");
                    subtract = true;
                    resultview.setText(null);
                }
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(resultview==null){
                    resultview.setText("");
                }
                else {
                    res1=Float.parseFloat(resultview.getText()+"");
                    multiply = true;
                    resultview.setText(null);
                }
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(resultview==null){
                    resultview.setText("");
                }
                else {
                    res1=Float.parseFloat(resultview.getText()+"");
                    division = true;
                    resultview.setText(null);
                }
            }
        });
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                res2=Float.parseFloat(resultview.getText()+"");
                if(summation == true){
                    resultview.setText(res1+res2+"");
                    summation=false;
                }
                if(subtract == true){
                    resultview.setText(res1-res2+"");
                    subtract=false;
                }
                if(multiply == true){
                    resultview.setText(res1*res2+"");
                    multiply=false;
                }
                if(division == true){
                    resultview.setText(res1/res2+"");
                    division=false;
                }
            }
        });
        backspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultview.setText("");
            }
        });

    }
}